﻿#requires -Version 5.0

$script:DzToolsConfigPath = "C:\Temp\dztools.ini"
$script:DzDebugEnabled = $null

function Get-DzToolsConfigPath {
    <#
    .SYNOPSIS
    Obtiene la ruta del archivo de configuración
    #>
    return $script:DzToolsConfigPath
}
function Get-DzDebugPreference {
    <#
    .SYNOPSIS
    Obtiene la preferencia de debug desde el archivo de configuración
    #>
    $configPath = Get-DzToolsConfigPath

    if (-not (Test-Path -LiteralPath $configPath)) {
        return $false
    }
    $content = Get-Content -LiteralPath $configPath -ErrorAction SilentlyContinue
    $inDevSection = $false
    foreach ($line in $content) {
        $trimmed = $line.Trim()
        if ($trimmed -match '^\s*;') { continue }
        if ($trimmed -match '^\[desarrollo\]\s*$') {
            $inDevSection = $true
            continue
        }
        if ($inDevSection -and $trimmed -match '^\[') {
            break
        }
        if ($inDevSection -and $trimmed -match '^\s*debug\s*=\s*(.+)\s*$') {
            return ($matches[1].ToLower() -eq 'true')
        }
    }
    return $false
}
function Initialize-DzToolsConfig {
    <#
    .SYNOPSIS
    Inicializa el archivo de configuración
    #>
    $configPath = Get-DzToolsConfigPath
    $configDir = Split-Path -Path $configPath -Parent
    if (-not (Test-Path -LiteralPath $configDir)) {
        New-Item -ItemType Directory -Path $configDir -Force | Out-Null
    }
    if (-not (Test-Path -LiteralPath $configPath)) {
        "[desarrollo]`ndebug=false" | Out-File -FilePath $configPath -Encoding UTF8 -Force
    }
    $script:DzDebugEnabled = Get-DzDebugPreference
    return $script:DzDebugEnabled
}
function Write-DzDebug {
    <#
    .SYNOPSIS
    Escribe mensajes de debug si está habilitado
    #>
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,

        [Parameter()]
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Gray
    )

    if ($null -eq $script:DzDebugEnabled) {
        $script:DzDebugEnabled = Get-DzDebugPreference
    }

    if ($script:DzDebugEnabled) {
        Write-Host $Message -ForegroundColor $Color
    }
}
function Test-Administrator {
    <#
    .SYNOPSIS
    Verifica si el script se ejecuta con privilegios de administrador
    #>
    [CmdletBinding()]
    param()
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Get-SystemInfo {
    <#
    .SYNOPSIS
    Obtiene información del sistema
    #>
    [CmdletBinding()]
    param()
    $info = @{
        ComputerName      = [System.Net.Dns]::GetHostName()
        OS                = (Get-CimInstance -ClassName Win32_OperatingSystem).Caption
        PowerShellVersion = $PSVersionTable.PSVersion.ToString()
        NetAdapters       = @()
    }
    $adapters = Get-NetAdapter | Where-Object { $_.Status -eq 'Up' }
    foreach ($adapter in $adapters) {
        $adapterInfo = @{
            Name        = $adapter.Name
            Status      = $adapter.Status
            MacAddress  = $adapter.MacAddress
            IPAddresses = @()
        }
        $ipAddresses = Get-NetIPAddress -InterfaceAlias $adapter.Name -AddressFamily IPv4 |
        Where-Object { $_.IPAddress -ne '127.0.0.1' }

        foreach ($ip in $ipAddresses) {
            $adapterInfo.IPAddresses += $ip.IPAddress
        }
        $info.NetAdapters += $adapterInfo
    }
    return $info
}
function Clear-TemporaryFiles {
    <#
    .SYNOPSIS
    Limpia archivos temporales del sistema
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string[]]$Paths = @("$env:TEMP", "C:\Windows\Temp")
    )
    $totalDeleted = 0
    $totalSize = 0
    foreach ($path in $Paths) {
        if (Test-Path $path) {
            try {
                $items = Get-ChildItem -Path $path -Recurse -Force -ErrorAction SilentlyContinue
                foreach ($item in $items) {
                    try {
                        if ($item.PSIsContainer) {
                            Remove-Item -Path $item.FullName -Recurse -Force -ErrorAction SilentlyContinue
                        } else {
                            $totalSize += $item.Length
                            Remove-Item -Path $item.FullName -Force -ErrorAction SilentlyContinue
                        }
                        $totalDeleted++
                    } catch {
                        Write-Verbose "No se pudo eliminar: $($item.FullName)"
                    }
                }
            } catch {
                Write-Warning "Error accediendo a $path : $_"
            }
        }
    }
    return @{
        FilesDeleted = $totalDeleted
        SpaceFreedMB = [math]::Round($totalSize / 1MB, 2)
    }
}
function Test-ChocolateyInstalled {
    <#
    .SYNOPSIS
    Verifica si Chocolatey está instalado
    #>
    [CmdletBinding()]
    param()
    return [bool](Get-Command choco -ErrorAction SilentlyContinue)
}
function Install-Chocolatey {
    <#
    .SYNOPSIS
    Instala Chocolatey
    #>
    [CmdletBinding()]
    param()
    if (Test-ChocolateyInstalled) {
        Write-Verbose "Chocolatey ya está instalado"
        return $true
    }
    try {
        Write-Host "Instalando Chocolatey..." -ForegroundColor Yellow
        Set-ExecutionPolicy Bypass -Scope Process -Force
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
        Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
        choco config set cacheLocation C:\Choco\cache
        Write-Host "Chocolatey instalado correctamente" -ForegroundColor Green
        return $true
    } catch {
        Write-Error "Error instalando Chocolatey: $_"
        return $false
    }
}
function Get-AdminGroupName {
    <#
    .SYNOPSIS
    Obtiene el nombre del grupo de administradores del sistema
    #>
    $groups = net localgroup | Where-Object { $_ -match "Administrador|Administrators" }
    if ($groups -match "\bAdministradores\b") {
        return "Administradores"
    } elseif ($groups -match "\bAdministrators\b") {
        return "Administrators"
    }
    try {
        $adminGroup = Get-LocalGroup | Where-Object { $_.SID -like "S-1-5-32-544" }
        return $adminGroup.Name
    } catch {
        return "Administrators"
    }
}
function Invoke-DiskCleanup {
    <#
    .SYNOPSIS
    Ejecuta el liberador de espacio en disco de Windows
    #>
    [CmdletBinding()]
    param(
        [switch]$Configure,
        [switch]$Wait,
        [int]$TimeoutMinutes = 3,
        $ProgressWindow = $null
    )
    try {
        $cleanmgr = Join-Path $env:SystemRoot "System32\cleanmgr.exe"
        $profileId = 9999
        Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: INICIO Configure=$Configure, Wait=$Wait, TimeoutMinutes=$TimeoutMinutes"
        if ($Configure) {
            Write-Host "`n`tAbriendo configuración del Liberador de espacio..." -ForegroundColor Cyan
            Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: lanzando /sageset:$profileId"
            Start-Process $cleanmgr -ArgumentList "/sageset:$profileId" -Verb RunAs
            return
        }
        Write-Host "`n`tEjecutando Liberador de espacio en disco..." -ForegroundColor Cyan
        if ($Wait) {
            Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: lanzando /sagerun:$profileId (BLOQUEANTE con timeout)"
            Write-Host "`n`tEsperando a que termine la limpieza de disco..." -ForegroundColor Yellow
            Write-Host "`t(Timeout: $TimeoutMinutes minutos)" -ForegroundColor Yellow
            $proc = Start-Process $cleanmgr -ArgumentList "/sagerun:$profileId" -WindowStyle Hidden -PassThru
            if ($null -eq $proc) {
                throw "Invoke-DiskCleanup: Start-Process devolvió NULL (no se pudo iniciar cleanmgr)."
            }
            Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: Proceso iniciado. PID=$($proc.Id)"
            $timeoutSeconds = $TimeoutMinutes * 60
            $script:remainingSeconds = $timeoutSeconds
            $script:cleanupCompleted = $false
            # antes del if ($ProgressWindow...)
            $timer = $null

            if ($ProgressWindow -ne $null -and $ProgressWindow.IsVisible) {

                $timer = New-Object System.Windows.Threading.DispatcherTimer
                $timer.Interval = [TimeSpan]::FromSeconds(1)

                $timer.Add_Tick({
                        param($sender, $e)

                        try {
                            if ($script:remainingSeconds -gt 0) {
                                $script:remainingSeconds--

                                $mins = [math]::Floor($script:remainingSeconds / 60)
                                $secs = $script:remainingSeconds % 60

                                if ($ProgressWindow -and $ProgressWindow.PSObject.Properties.Name -contains 'MessageLabel') {
                                    $ProgressWindow.MessageLabel.Text = "Liberando espacio en disco...`nTiempo restante: $mins min $secs seg"
                                }
                            } else {
                                # ✅ en vez de $this.Stop()
                                $sender.Stop()
                            }
                        } catch {
                            Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: Tick EXCEPCIÓN: $($_.Exception.Message)" Red
                            $sender.Stop()
                        }
                    })

                $timer.Start()
                Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: Timer iniciado"
            }
            $checkInterval = 500
            $elapsed = 0
            while (-not $proc.HasExited -and $elapsed -lt ($timeoutSeconds * 1000)) {
                Start-Sleep -Milliseconds $checkInterval
                $elapsed += $checkInterval
                if ($ProgressWindow -ne $null -and $ProgressWindow.IsVisible) {
                    $ProgressWindow.Dispatcher.Invoke(
                        [System.Windows.Threading.DispatcherPriority]::Background,
                        [action] {}
                    )
                }
            }
            if ($timer) {
                $timer.Stop()
            }
            if ($proc.HasExited) {
                Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: Proceso completado. ExitCode=$($proc.ExitCode)"
                Write-Host "`n`tLiberador de espacio completado." -ForegroundColor Green
                if ($ProgressWindow -ne $null -and $ProgressWindow.IsVisible) {
                    if ($ProgressWindow.PSObject.Properties.Name -contains 'MessageLabel') {
                        $ProgressWindow.MessageLabel.Text = "Limpieza completada exitosamente"
                    }
                }
            } else {
                Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: TIMEOUT alcanzado" Yellow
                Write-Host "`n`tAdvertencia: El proceso excedió el tiempo límite." -ForegroundColor Yellow
                try {
                    $proc.Kill()
                    $proc.WaitForExit(5000)
                    Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: Proceso terminado forzosamente"
                } catch {
                    Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: Error al terminar proceso" Red
                }
            }
        } else {
            Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: lanzando /sagerun:$profileId (NO bloqueante)"
            $proc = Start-Process $cleanmgr `
                -ArgumentList "/sagerun:$profileId" `
                -WindowStyle Hidden `
                -PassThru
            Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: lanzado. PID=$($proc.Id)"
            Write-Host "`n`tLiberador de espacio iniciado." -ForegroundColor Green
        }
        Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: FIN OK"
    } catch {
        Write-DzDebug "`t[DEBUG]Invoke-DiskCleanup: EXCEPCIÓN: $($_.Exception.Message)" Red
        Write-Host "`n`tError en limpieza de disco: $($_.Exception.Message)" -ForegroundColor Red
    }
}
function Stop-CleanmgrProcesses {
    <#
    .SYNOPSIS
    Detiene todos los procesos de cleanmgr activos
    #>
    [CmdletBinding()]
    param()
    try {
        $cleanmgrProcesses = Get-Process -Name "cleanmgr" -ErrorAction SilentlyContinue
        if ($cleanmgrProcesses) {
            Write-Host "`n`tEncontrando procesos cleanmgr activos..." -ForegroundColor Yellow
            Write-DzDebug "`t[DEBUG]Stop-CleanmgrProcesses: Encontrados $($cleanmgrProcesses.Count) procesos"
            foreach ($proc in $cleanmgrProcesses) {
                Write-Host "`t  Terminando proceso cleanmgr (PID: $($proc.Id))..." -ForegroundColor Yellow
                $proc.Kill()
                Start-Sleep -Milliseconds 500
            }
            Write-Host "`tProcesos cleanmgr terminados." -ForegroundColor Green
            Write-DzDebug "`t[DEBUG]Stop-CleanmgrProcesses: Procesos terminados"
        } else {
            Write-DzDebug "`t[DEBUG]Stop-CleanmgrProcesses: No hay procesos cleanmgr activos"
        }
    } catch {
        Write-DzDebug "`t[DEBUG]Stop-CleanmgrProcesses: Error: $($_.Exception.Message)" Red
        Write-Host "`tError al terminar procesos: $($_.Exception.Message)" -ForegroundColor Red
    }
}
function Show-SystemComponents {
    <#
    .SYNOPSIS
    Muestra los componentes del sistema detectados
    #>
    param(
        [switch]$SkipOnError
    )
    Write-Host "`n=== Componentes del sistema detectados ===" -ForegroundColor Cyan
    $os = $null
    $maxAttempts = 3
    $retryDelaySeconds = 2
    for ($attempt = 1; $attempt -le $maxAttempts -and -not $os; $attempt++) {
        try {
            $os = Get-CimInstance -ClassName CIM_OperatingSystem -ErrorAction Stop
        } catch {
            if ($attempt -lt $maxAttempts) {
                $msg = "Show-SystemComponents: ERROR intento {0}: {1}. Reintento en {2}s" -f `
                    $attempt, $_.Exception.Message, $retryDelaySeconds

                Write-Host $msg -ForegroundColor DarkYellow
                Start-Sleep -Seconds $retryDelaySeconds
            } else {
                Write-Host "`n[Windows]" -ForegroundColor Yellow
                Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red

                if (-not $SkipOnError) {
                    throw "No se pudo obtener información crítica del sistema"
                } else {
                    Write-Host "Continuando sin información del sistema..." -ForegroundColor Yellow
                    return
                }
            }
        }
    }
    if (-not $os) {
        if (-not $SkipOnError) {
            throw "No se pudo obtener información crítica del sistema"
        }
        return
    }
    Write-Host "`n[Windows]" -ForegroundColor Yellow
    Write-Host "Versión: $($os.Caption) (Build $($os.Version))" -ForegroundColor White
    try {
        Write-DzDebug "`t[DEBUG]Show-SystemComponents: Obteniendo CIM_Processor..."
        $procesador = Get-CimInstance -ClassName CIM_Processor -ErrorAction Stop
        Write-Host "`n[Procesador]" -ForegroundColor Yellow
        Write-Host "Modelo: $($procesador.Name)" -ForegroundColor White
        Write-Host "Núcleos: $($procesador.NumberOfCores)" -ForegroundColor White
    } catch {
        Write-DzDebug "`t[DEBUG]Show-SystemComponents: Error leyendo procesador" Red
        Write-Host "`n[Procesador]" -ForegroundColor Yellow
        Write-Host "Error de lectura: $($_.Exception.Message)" -ForegroundColor Red
    }
    try {
        Write-DzDebug "`t[DEBUG]Show-SystemComponents: Obteniendo CIM_PhysicalMemory..."
        $memoria = Get-CimInstance -ClassName CIM_PhysicalMemory -ErrorAction Stop
        Write-Host "`n[Memoria RAM]" -ForegroundColor Yellow
        $memoria | ForEach-Object {
            Write-Host "Módulo: $([math]::Round($_.Capacity/1GB, 2)) GB $($_.Manufacturer) ($($_.Speed) MHz)" -ForegroundColor White
        }
    } catch {
        Write-DzDebug "`t[DEBUG]Show-SystemComponents: Error leyendo memoria" Red
        Write-Host "`n[Memoria RAM]" -ForegroundColor Yellow
        Write-Host "Error de lectura: $($_.Exception.Message)" -ForegroundColor Red
    }
    try {
        Write-DzDebug "`t[DEBUG]Show-SystemComponents: Obteniendo CIM_DiskDrive..."
        $discos = Get-CimInstance -ClassName CIM_DiskDrive -ErrorAction Stop
        Write-Host "`n[Discos duros]" -ForegroundColor Yellow
        $discos | ForEach-Object {
            Write-Host "Disco: $($_.Model) ($([math]::Round($_.Size/1GB, 2)) GB)" -ForegroundColor White
        }
    } catch {
        Write-DzDebug "`t[DEBUG]Show-SystemComponents: Error leyendo discos" Red
        Write-Host "`n[Discos duros]" -ForegroundColor Yellow
        Write-Host "Error de lectura: $($_.Exception.Message)" -ForegroundColor Red
    }
    Write-DzDebug "`t[DEBUG]Show-SystemComponents: FIN"
}
function Test-SameHost {
    <#
    .SYNOPSIS
    Verifica si el servidor SQL está en el mismo host
    #>
    param(
        [string]$serverName
    )
    $machinePart = $serverName.Split('\')[0]
    $machineName = $machinePart.Split(',')[0]
    if ($machineName -eq '.') {
        $machineName = $env:COMPUTERNAME
    }
    return ($env:COMPUTERNAME -eq $machineName)
}
function Test-7ZipInstalled {
    <#
    .SYNOPSIS
    Verifica si 7-Zip está instalado
    #>
    return (Test-Path "C:\Program Files\7-Zip\7z.exe")
}
function Test-MegaToolsInstalled {
    <#
    .SYNOPSIS
    Verifica si MegaTools está instalado
    #>
    return ([bool](Get-Command megatools -ErrorAction SilentlyContinue))
}
function Check-Permissions {
    <#
    .SYNOPSIS
    Verifica y opcionalmente modifica permisos de carpeta
    #>
    param(
        [string]$folderPath = "C:\NationalSoft"
    )
    if (-not (Test-Path -LiteralPath $folderPath)) {
        Write-Host "La carpeta $folderPath no existe." -ForegroundColor Red

        [System.Windows.MessageBox]::Show(
            "La carpeta '$folderPath' no existe en este equipo.`r`nCrea la carpeta o corrige la ruta antes de continuar.",
            "Carpeta no encontrada",
            [System.Windows.MessageBoxButton]::OK,
            [System.Windows.MessageBoxImage]::Warning
        ) | Out-Null
        return
    }
    try {
        $acl = Get-Acl -LiteralPath $folderPath -ErrorAction Stop
    } catch {
        Write-Host "Error obteniendo ACL de $folderPath : $_" -ForegroundColor Red
        [System.Windows.MessageBox]::Show(
            "Error obteniendo permisos de '$folderPath':`r`n$($_.Exception.Message)",
            "Error al obtener permisos",
            [System.Windows.MessageBoxButton]::OK,
            [System.Windows.MessageBoxImage]::Error
        ) | Out-Null
        return
    }
    $permissions = @()
    $everyoneSid = New-Object System.Security.Principal.SecurityIdentifier(
        [System.Security.Principal.WellKnownSidType]::WorldSid,
        $null
    )
    $everyonePermissions = @()
    $everyoneHasFullControl = $false
    foreach ($access in $acl.Access) {
        try {
            $userSid = ($access.IdentityReference).Translate(
                [System.Security.Principal.SecurityIdentifier]
            )
        } catch {
            continue
        }
        $permissions += [PSCustomObject]@{
            Usuario = $access.IdentityReference
            Permiso = $access.FileSystemRights
            Tipo    = $access.AccessControlType
        }
        if ($userSid -eq $everyoneSid) {
            $everyonePermissions += $access.FileSystemRights
            if ($access.FileSystemRights -match "FullControl") {
                $everyoneHasFullControl = $true
            }
        }
    }
    Write-Host ""
    Write-Host "Permisos en $folderPath :" -ForegroundColor Cyan
    $permissions | ForEach-Object {
        Write-Host "`t$($_.Usuario) - $($_.Tipo) - $($_.Permiso)" -ForegroundColor Green
    }
    if ($everyonePermissions.Count -gt 0) {
        Write-Host "`tEveryone tiene: $($everyonePermissions -join ', ')" -ForegroundColor Green
    } else {
        Write-Host "`tNo hay permisos para 'Everyone'" -ForegroundColor Red
    }
    if (-not $everyoneHasFullControl) {
        $result = [System.Windows.MessageBox]::Show(
            "El usuario 'Everyone' no tiene permisos de 'Full Control'. ¿Deseas concederlo?",
            "Permisos 'Everyone'",
            [System.Windows.MessageBoxButton]::YesNo,
            [System.Windows.MessageBoxImage]::Question
        )
        if ($result -eq [System.Windows.MessageBoxResult]::Yes) {
            try {
                $directoryInfo = New-Object System.IO.DirectoryInfo($folderPath)
                $dirAcl = $directoryInfo.GetAccessControl()
                $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                    $everyoneSid,
                    [System.Security.AccessControl.FileSystemRights]::FullControl,
                    [System.Security.AccessControl.InheritanceFlags]"ContainerInherit, ObjectInherit",
                    [System.Security.AccessControl.PropagationFlags]::None,
                    [System.Security.AccessControl.AccessControlType]::Allow
                )
                $dirAcl.AddAccessRule($accessRule)
                $dirAcl.SetAccessRuleProtection($false, $true)
                $directoryInfo.SetAccessControl($dirAcl)
                Write-Host "Se ha concedido 'Full Control' a 'Everyone'." -ForegroundColor Green
                [System.Windows.MessageBox]::Show(
                    "Se ha concedido 'Full Control' a 'Everyone' en '$folderPath'.",
                    "Permisos actualizados",
                    [System.Windows.MessageBoxButton]::OK,
                    [System.Windows.MessageBoxImage]::Information
                ) | Out-Null
            } catch {
                Write-Host "Error aplicando permisos: $_" -ForegroundColor Red
                [System.Windows.MessageBox]::Show(
                    "Error aplicando permisos a '$folderPath':`r`n$($_.Exception.Message)",
                    "Error al aplicar permisos",
                    [System.Windows.MessageBoxButton]::OK,
                    [System.Windows.MessageBoxImage]::Error
                ) | Out-Null
            }
        }
    }
}

function Refresh-AdapterStatus {
    try {
        if ($null -eq $global:txt_AdapterStatus) {
            Write-Host "ADVERTENCIA: El control de estado de adaptadores no está disponible." -ForegroundColor Yellow
            return
        }

        $adapters = Get-NetAdapter | Where-Object { $_.Status -eq 'Up' }
        $adapterInfo = @()

        foreach ($adapter in $adapters) {
            $profile = Get-NetConnectionProfile -InterfaceAlias $adapter.Name -ErrorAction SilentlyContinue
            $networkType = if ($profile) {
                switch ($profile.NetworkCategory) {
                    'Private' { "Privada" }
                    'Public' { "Pública" }
                    'DomainAuthenticated' { "Dominio" }
                    default { "Desconocida" }
                }
            } else {
                "Sin perfil"
            }

            $adapterInfo += "$($adapter.Name): $networkType"
        }

        if ($adapterInfo.Count -gt 0) {
            $global:txt_AdapterStatus.Dispatcher.Invoke([action] {
                    $global:txt_AdapterStatus.Text = $adapterInfo -join "`n"
                })
        } else {
            $global:txt_AdapterStatus.Dispatcher.Invoke([action] {
                    $global:txt_AdapterStatus.Text = "Sin adaptadores activos"
                })
        }
    } catch {
        Write-Host "Error al actualizar estado de adaptadores: $_" -ForegroundColor Red
    }
}
function Get-NetworkAdapterStatus {
    <#
    .SYNOPSIS
    Obtiene el estado de los adaptadores de red
    #>
    $adapters = Get-NetAdapter | Where-Object { $_.Status -eq 'Up' }
    $profiles = Get-NetConnectionProfile
    $adapterStatus = @()
    foreach ($adapter in $adapters) {
        $profile = $profiles | Where-Object { $_.InterfaceIndex -eq $adapter.ifIndex }
        $networkCategory = if ($profile) { $profile.NetworkCategory } else { "Desconocido" }

        $adapterStatus += [PSCustomObject]@{
            AdapterName     = $adapter.Name
            NetworkCategory = $networkCategory
            InterfaceIndex  = $adapter.ifIndex
        }
    }
    return $adapterStatus
}
function Start-SystemUpdate {
    <#
    .SYNOPSIS
    Ejecuta el proceso completo de actualización del sistema
    #>
    param(
        [int]$DiskCleanupTimeoutMinutes = 3
    )
    $progressWindow = $null
    Write-DzDebug "`t[DEBUG]Start-SystemUpdate: INICIO (Timeout=$DiskCleanupTimeoutMinutes min)"
    try {
        $progressWindow = Show-WpfProgressBar -Title "Actualización del Sistema" -Message "Iniciando proceso..."
        $totalSteps = 5
        $currentStep = 0
        Write-Host "`nIniciando proceso de actualización..." -ForegroundColor Cyan
        Write-DzDebug "`t[DEBUG]Paso 1: Deteniendo servicio winmgmt..."
        Write-Host "`n[Paso 1/$totalSteps] Deteniendo servicio winmgmt..." -ForegroundColor Yellow
        $service = Get-Service -Name "winmgmt" -ErrorAction Stop
        Write-DzDebug "`t[DEBUG]Paso 1: Estado actual winmgmt=$($service.Status)"
        if ($service.Status -eq "Running") {
            Update-WpfProgressBar -Window $progressWindow -Percent 10 -Message "Deteniendo servicio WMI..."
            Stop-Service -Name "winmgmt" -Force -ErrorAction Stop
            Write-DzDebug "`t[DEBUG]Paso 1: winmgmt detenido OK"
            Write-Host "`n`tServicio detenido correctamente." -ForegroundColor Green
        }
        $currentStep++
        Update-WpfProgressBar -Window $progressWindow -Percent 20 -Message "Servicio WMI detenido"
        Start-Sleep -Milliseconds 500
        Write-DzDebug "`t[DEBUG]Paso 2: Renombrando carpeta Repository..."
        Write-Host "`n[Paso 2/$totalSteps] Renombrando carpeta Repository..." -ForegroundColor Yellow
        Update-WpfProgressBar -Window $progressWindow -Percent 30 -Message "Renombrando Repository..."
        try {
            $repoPath = Join-Path $env:windir "System32\Wbem\Repository"
            Write-DzDebug "`t[DEBUG]Paso 2: repoPath=$repoPath"

            if (Test-Path $repoPath) {
                $newName = "Repository_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
                Rename-Item -Path $repoPath -NewName $newName -Force -ErrorAction Stop
                Write-DzDebug "`t[DEBUG]Paso 2: Carpeta renombrada a $newName"
                Write-Host "`n`tCarpeta renombrada: $newName" -ForegroundColor Green
            }
        } catch {
            Write-DzDebug "`t[DEBUG]Paso 2: EXCEPCIÓN: $($_.Exception.Message)" Red
            Write-Host "`n`tAdvertencia: No se pudo renombrar Repository. Continuando..." -ForegroundColor Yellow
        }
        $currentStep++
        Update-WpfProgressBar -Window $progressWindow -Percent 40 -Message "Repository renovado"
        Start-Sleep -Milliseconds 500
        Write-DzDebug "`t[DEBUG]Paso 3: Reiniciando servicio winmgmt..."
        Write-Host "`n[Paso 3/$totalSteps] Reiniciando servicio winmgmt..." -ForegroundColor Yellow
        Update-WpfProgressBar -Window $progressWindow -Percent 50 -Message "Reiniciando servicio WMI..."
        net start winmgmt *>&1 | Write-Host
        Write-DzDebug "`t[DEBUG]Paso 3: winmgmt reiniciado"
        Write-Host "`n`tServicio WMI reiniciado." -ForegroundColor Green
        $currentStep++
        Update-WpfProgressBar -Window $progressWindow -Percent 60 -Message "Servicio WMI reiniciado"
        Start-Sleep -Milliseconds 500
        Write-DzDebug "`t[DEBUG]Paso 4: Limpiando archivos temporales..."
        Write-Host "`n[Paso 4/$totalSteps] Limpiando archivos temporales..." -ForegroundColor Cyan
        Update-WpfProgressBar -Window $progressWindow -Percent 70 -Message "Limpiando archivos temporales..."
        $cleanupResult = Clear-TemporaryFiles
        Write-DzDebug "`t[DEBUG]Paso 4: FilesDeleted=$($cleanupResult.FilesDeleted) SpaceFreedMB=$($cleanupResult.SpaceFreedMB)"
        Write-Host "`n`tTotal archivos eliminados: $($cleanupResult.FilesDeleted)" -ForegroundColor Green
        Write-Host "`n`tEspacio liberado: $($cleanupResult.SpaceFreedMB) MB" -ForegroundColor Green
        $currentStep++
        Update-WpfProgressBar -Window $progressWindow -Percent 80 -Message "Archivos temporales limpiados"
        Start-Sleep -Milliseconds 500
        Write-DzDebug "`t[DEBUG]Paso 5: Ejecutando Liberador de espacio..."
        Write-Host "`n[Paso 5/$totalSteps] Ejecutando Liberador de espacio..." -ForegroundColor Cyan
        Update-WpfProgressBar -Window $progressWindow -Percent 90 -Message "Preparando limpieza de disco..."
        Invoke-DiskCleanup -Wait -TimeoutMinutes $DiskCleanupTimeoutMinutes -ProgressWindow $progressWindow
        Write-DzDebug "`t[DEBUG]Paso 5: Liberador completado"
        $currentStep++
        Update-WpfProgressBar -Window $progressWindow -Percent 100 -Message "Proceso completado exitosamente"
        Start-Sleep -Seconds 1
        if ($progressWindow -ne $null -and $progressWindow.IsVisible) {
            Close-WpfProgressBar -Window $progressWindow
            $progressWindow = $null
        }
        Write-Host "`n`n============================================" -ForegroundColor Green
        Write-Host "   Proceso de actualización completado" -ForegroundColor Green
        Write-Host "============================================" -ForegroundColor Green
        Write-Host "`nSe recomienda REINICIAR el equipo" -ForegroundColor Yellow
        Write-DzDebug "`t[DEBUG]Start-SystemUpdate: Mostrando diálogo de reinicio"
        $result = [System.Windows.MessageBox]::Show(
            "El proceso de actualización se completó exitosamente.`n`n" +
            "Se recomienda REINICIAR el equipo para completar la actualización del sistema WMI.`n`n" +
            "¿Desea reiniciar ahora?",
            "Actualización completada",
            [System.Windows.MessageBoxButton]::YesNo,
            [System.Windows.MessageBoxImage]::Question
        )
        if ($result -eq [System.Windows.MessageBoxResult]::Yes) {
            Write-Host "`n`tReiniciando equipo en 10 segundos..." -ForegroundColor Yellow
            Write-DzDebug "`t[DEBUG]Start-SystemUpdate: Usuario eligió reiniciar"
            Start-Sleep -Seconds 3
            shutdown /r /t 10 /c "Reinicio para completar actualización de sistema WMI"
        } else {
            Write-Host "`n`tRecuerde reiniciar el equipo más tarde." -ForegroundColor Yellow
            Write-DzDebug "`t[DEBUG]Start-SystemUpdate: Usuario canceló reinicio"
        }
        Write-DzDebug "`t[DEBUG]Start-SystemUpdate: FIN OK"
        return $true
    } catch {
        Write-DzDebug "`t[DEBUG]Start-SystemUpdate: EXCEPCIÓN: $($_.Exception.Message)" Red
        Write-DzDebug "`t[DEBUG]Start-SystemUpdate: ScriptStackTrace: $($_.ScriptStackTrace)" Red
        Write-Host "`nERROR: $($_.Exception.Message)" -ForegroundColor Red        [System.Windows.MessageBox]::Show(
            "Error durante la actualización: $($_.Exception.Message)`n`n" +
            "Revise los logs y considere reiniciar manualmente el equipo.",
            "Error en actualización",
            [System.Windows.MessageBoxButton]::OK,
            [System.Windows.MessageBoxImage]::Error
        ) | Out-Null
        return $false
    } finally {
        Write-DzDebug "`t[DEBUG]Start-SystemUpdate: FINALLY (cerrando progressWindow)"
        if ($progressWindow -ne $null -and $progressWindow.IsVisible) {
            Close-WpfProgressBar -Window $progressWindow
        }
    }
}
function Get-SqlPortWithDebug {
    Write-DzDebug "`n[DEBUG] === INICIANDO BÚSQUEDA DE PUERTOS SQL ==="
    Write-DzDebug "`t[DEBUG] Fecha/Hora: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"

    $ports = @()

    # Definir rutas de registro a buscar (64-bit y 32-bit)
    $registryPaths = @(
        "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server",  # 64-bit
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Microsoft SQL Server"  # 32-bit
    )

    # 1. Buscar por todas las instancias instaladas
    Write-DzDebug "`t[DEBUG] 1. Buscando instancias SQL instaladas..."

    foreach ($basePath in $registryPaths) {
        try {
            Write-DzDebug "`t[DEBUG]   Examinando ruta: $basePath"

            if (-not (Test-Path $basePath)) {
                Write-DzDebug "`t[DEBUG]   ✗ La ruta no existe"
                continue
            }

            # Método 1: Obtener de InstalledInstances
            Write-DzDebug "`t[DEBUG]   Método 1: Buscando en 'InstalledInstances'..."
            $installedInstances = Get-ItemProperty -Path $basePath -Name "InstalledInstances" -ErrorAction SilentlyContinue

            if ($installedInstances -and $installedInstances.InstalledInstances) {
                Write-DzDebug "`t[DEBUG]   ✓ Instancias encontradas: $($installedInstances.InstalledInstances -join ', ')"

                foreach ($instance in $installedInstances.InstalledInstances) {
                    # Si ya procesamos esta instancia, saltar
                    if ($ports.Instance -contains $instance) {
                        Write-DzDebug "`t[DEBUG]     Instancia '$instance' ya procesada, saltando..."
                        continue
                    }

                    Write-DzDebug "`t[DEBUG]     Procesando instancia: '$instance'"

                    # Construir rutas posibles para esta instancia
                    $possiblePaths = @(
                        "$basePath\$instance\MSSQLServer\SuperSocketNetLib\Tcp",
                        "$basePath\$instance\MSSQLServer\SuperSocketNetLib\Tcp\IPAll",
                        "$basePath\MSSQLServer\$instance\SuperSocketNetLib\Tcp"
                    )

                    $portFound = $false
                    foreach ($tcpPath in $possiblePaths) {
                        Write-DzDebug "`t[DEBUG]       Probando ruta: $tcpPath"

                        if (Test-Path $tcpPath) {
                            Write-DzDebug "`t[DEBUG]       ✓ Ruta existe"

                            # Buscar puerto TCP
                            $tcpPort = Get-ItemProperty -Path $tcpPath -Name "TcpPort" -ErrorAction SilentlyContinue
                            $tcpDynamicPorts = Get-ItemProperty -Path $tcpPath -Name "TcpDynamicPorts" -ErrorAction SilentlyContinue

                            if ($tcpPort -and $tcpPort.TcpPort) {
                                $portInfo = [PSCustomObject]@{
                                    Instance = $instance
                                    Port     = $tcpPort.TcpPort
                                    Path     = $tcpPath
                                    Type     = "Static"
                                }
                                $ports += $portInfo
                                Write-DzDebug "`t[DEBUG]       ✓ Puerto estático encontrado: $($tcpPort.TcpPort)"
                                $portFound = $true
                                break
                            } elseif ($tcpDynamicPorts -and $tcpDynamicPorts.TcpDynamicPorts) {
                                $portInfo = [PSCustomObject]@{
                                    Instance = $instance
                                    Port     = $tcpDynamicPorts.TcpDynamicPorts
                                    Path     = $tcpPath
                                    Type     = "Dynamic"
                                }
                                $ports += $portInfo
                                Write-DzDebug "`t[DEBUG]       ✓ Puerto dinámico encontrado: $($tcpDynamicPorts.TcpDynamicPorts)"
                                $portFound = $true
                                break
                            } else {
                                Write-DzDebug "`t[DEBUG]       ✗ No se encontró puerto en esta ruta"
                            }
                        } else {
                            Write-DzDebug "`t[DEBUG]       ✗ Ruta no existe"
                        }
                    }

                    if (-not $portFound) {
                        Write-DzDebug "`t[DEBUG]     ✗ No se encontró puerto para la instancia '$instance'"
                    }
                }
            } else {
                Write-DzDebug "`t[DEBUG]   ✗ No se encontró la clave 'InstalledInstances' en esta ruta"
            }

            # Método 2: Explorar todas las carpetas bajo SQL Server
            Write-DzDebug "`t[DEBUG]   Método 2: Explorando todas las carpetas..."

            $allSqlEntries = Get-ChildItem -Path $basePath -ErrorAction SilentlyContinue |
            Where-Object { $_.PSIsContainer } |
            Select-Object -ExpandProperty PSChildName

            if ($allSqlEntries) {
                Write-DzDebug "`t[DEBUG]   Carpetas encontradas: $($allSqlEntries -join ', ')"

                foreach ($entry in $allSqlEntries) {
                    # Filtrar nombres que parecen instancias
                    if ($entry -match "^MSSQL\d+" -or $entry -match "^SQL" -or $entry -match "NATIONALSOFT") {
                        # Si ya procesamos esta instancia, saltar
                        if ($ports.Instance -contains $entry) {
                            Write-DzDebug "`t[DEBUG]     Instancia '$entry' ya procesada, saltando..."
                            continue
                        }

                        Write-DzDebug "`t[DEBUG]     Analizando posible instancia: '$entry'"

                        $tcpPath = "$basePath\$entry\MSSQLServer\SuperSocketNetLib\Tcp"

                        if (Test-Path $tcpPath) {
                            Write-DzDebug "`t[DEBUG]       ✓ Ruta TCP encontrada: $tcpPath"

                            $tcpPort = Get-ItemProperty -Path $tcpPath -Name "TcpPort" -ErrorAction SilentlyContinue
                            $tcpDynamicPorts = Get-ItemProperty -Path $tcpPath -Name "TcpDynamicPorts" -ErrorAction SilentlyContinue

                            if ($tcpPort -and $tcpPort.TcpPort) {
                                $portInfo = [PSCustomObject]@{
                                    Instance = $entry
                                    Port     = $tcpPort.TcpPort
                                    Path     = $tcpPath
                                    Type     = "Static"
                                }
                                $ports += $portInfo
                                Write-DzDebug "`t[DEBUG]       ✓ Puerto estático encontrado: $($tcpPort.TcpPort)"
                            } elseif ($tcpDynamicPorts -and $tcpDynamicPorts.TcpDynamicPorts) {
                                $portInfo = [PSCustomObject]@{
                                    Instance = $entry
                                    Port     = $tcpDynamicPorts.TcpDynamicPorts
                                    Path     = $tcpPath
                                    Type     = "Dynamic"
                                }
                                $ports += $portInfo
                                Write-DzDebug "`t[DEBUG]       ✓ Puerto dinámico encontrado: $($tcpDynamicPorts.TcpDynamicPorts)"
                            } else {
                                Write-DzDebug "`t[DEBUG]       ✗ No se encontró puerto en esta ruta"
                            }
                        }
                    }
                }
            }

        } catch {
            Write-DzDebug "`t[DEBUG]   ERROR en búsqueda: $($_.Exception.Message)"
            Write-DzDebug "`t[DEBUG]   StackTrace: $($_.ScriptStackTrace)"
        }
    }

    # Método 3: Buscar por servicios SQL Server (común para ambos)
    Write-DzDebug "`t[DEBUG]   Método 3: Buscando servicios SQL Server..."

    $sqlServices = Get-Service -Name "*SQL*" -ErrorAction SilentlyContinue |
    Where-Object { $_.DisplayName -like "*SQL Server (*" }

    foreach ($service in $sqlServices) {
        Write-DzDebug "`t[DEBUG]     Servicio: $($service.DisplayName)"

        # Extraer nombre de instancia del servicio
        if ($service.DisplayName -match "SQL Server \((.+)\)") {
            $instanceName = $matches[1]

            # Si ya procesamos esta instancia, saltar
            if ($ports.Instance -contains $instanceName) {
                Write-DzDebug "`t[DEBUG]       Instancia '$instanceName' ya procesada, saltando..."
                continue
            }

            Write-DzDebug "`t[DEBUG]       Posible instancia: '$instanceName'"
            # Buscar en ambas rutas del registro
            foreach ($basePath in $registryPaths) {
                $tcpPath = "$basePath\MSSQLServer\$instanceName\SuperSocketNetLib\Tcp"

                if (Test-Path $tcpPath) {
                    $tcpPort = Get-ItemProperty -Path $tcpPath -Name "TcpPort" -ErrorAction SilentlyContinue
                    $tcpDynamicPorts = Get-ItemProperty -Path $tcpPath -Name "TcpDynamicPorts" -ErrorAction SilentlyContinue

                    if ($tcpPort -and $tcpPort.TcpPort) {
                        $portInfo = [PSCustomObject]@{
                            Instance = $instanceName
                            Port     = $tcpPort.TcpPort
                            Path     = $tcpPath
                            Type     = "Static"
                        }
                        $ports += $portInfo
                        Write-DzDebug "`t[DEBUG]       ✓ Puerto estático encontrado: $($tcpPort.TcpPort)"
                        break
                    } elseif ($tcpDynamicPorts -and $tcpDynamicPorts.TcpDynamicPorts) {
                        $portInfo = [PSCustomObject]@{
                            Instance = $instanceName
                            Port     = $tcpDynamicPorts.TcpDynamicPorts
                            Path     = $tcpPath
                            Type     = "Dynamic"
                        }
                        $ports += $portInfo
                        Write-DzDebug "`t[DEBUG]       ✓ Puerto dinámico encontrado: $($tcpDynamicPorts.TcpDynamicPorts)"
                        break
                    }
                }
            }
        }
    }

    # Método 4: Buscar puertos en uso por SQL Server
    Write-DzDebug "`t[DEBUG]   Método 4: Buscando puertos en uso por sqlservr.exe..."

    $sqlProcesses = Get-Process -Name "sqlservr" -ErrorAction SilentlyContinue
    if ($sqlProcesses) {
        foreach ($process in $sqlProcesses) {
            Write-DzDebug "`t[DEBUG]     Proceso sqlservr.exe encontrado (PID: $($process.Id))"

            # Obtener puertos usando netstat
            $netstatOutput = netstat -ano | Select-String ":$($process.Id)\s"

            foreach ($line in $netstatOutput) {
                if ($line -match ":(\d+)\s.*$($process.Id)$") {
                    $port = $matches[1]
                    Write-DzDebug "`t[DEBUG]       Puerto en uso: $port"

                    # Si no tenemos esta instancia en la lista, agregarla
                    if (-not ($ports.Port -contains $port)) {
                        # Intentar obtener nombre de instancia del proceso
                        $processInfo = Get-WmiObject Win32_Process -Filter "ProcessId = $($process.Id)" | Select-Object CommandLine
                        if ($processInfo.CommandLine -match "-s(.+?)\s") {
                            $instanceFromCmd = $matches[1]
                        } else {
                            $instanceFromCmd = "Unknown"
                        }

                        $portInfo = [PSCustomObject]@{
                            Instance = $instanceFromCmd
                            Port     = $port
                            Path     = "From Process"
                            Type     = "In Use"
                        }
                        $ports += $portInfo
                    }
                }
            }
        }
    } else {
        Write-DzDebug "`t[DEBUG]     ✗ No se encontraron procesos sqlservr.exe"
    }

    # Resumen final
    Write-DzDebug "`t[DEBUG] `n=== RESUMEN DE BÚSQUEDA ==="
    Write-DzDebug "`t[DEBUG] Total de instancias con puerto encontradas: $($ports.Count)"

    if ($ports.Count -gt 0) {
        foreach ($port in $ports) {
            Write-DzDebug "`t[DEBUG]   - Instancia: $($port.Instance) | Puerto: $($port.Port) | Tipo: $($port.Type)"
            Write-DzDebug "`t[DEBUG]     Ruta: $($port.Path)"
        }
    } else {
        Write-DzDebug "`t[DEBUG]   ✗ No se encontraron puertos SQL configurados"

        # Sugerencias para debugging
        Write-DzDebug "`t[DEBUG] `n=== SUGERENCIAS ==="
        Write-DzDebug "`t[DEBUG] 1. Verifica si SQL Server está instalado"
        Write-DzDebug "`t[DEBUG] 2. Revisa el Configuration Manager de SQL Server"
        Write-DzDebug "`t[DEBUG] 3. Verifica si el servicio SQL Server está ejecutándose"
        Write-DzDebug "`t[DEBUG] 4. Consulta el log de errores de SQL Server"
    }
    Write-DzDebug "`t[DEBUG] === FIN DE BÚSQUEDA ===`n"
    if ($ports.Count -gt 0) {
        # Ordenar por instancia
        $ports = $ports | Sort-Object -Property Instance
        # Formatear cada puerto con una línea por instancia
        $formattedPorts = @()
        foreach ($port in $ports) {
            # Formatear nombre de instancia
            $instanceName = if ($port.Instance -eq "MSSQLSERVER") { "Default" } else { $port.Instance }
            # Crear un nuevo objeto con todas las propiedades necesarias
            $formattedPort = [PSCustomObject]@{
                Instance       = $port.Instance
                Port           = $port.Port
                Path           = $port.Path
                Type           = $port.Type
                FormattedText  = "$instanceName`: $($port.Port)"
                SingleLineText = "$instanceName`: $($port.Port) - $($port.Type)"
            }
            $formattedPorts += $formattedPort
        }
        $ports = $formattedPorts
    }
    return $ports
}
function Show-SqlPortsInfo {
    param([array]$sqlPorts)
    if ($sqlPorts.Count -eq 0) {
        Write-Host "=== RESUMEN DE BÚSQUEDA SQL ===" -ForegroundColor Yellow
        Write-Host "No se encontraron puertos SQL ni instalaciones de SQL Server" -ForegroundColor Red
        Write-Host "=== FIN DE BÚSQUEDA ===" -ForegroundColor Yellow
        return
    }
    Write-Host "`n=== RESUMEN DE BÚSQUEDA SQL ===" -ForegroundColor Cyan
    Write-Host "Total de instancias con puerto encontradas: $($sqlPorts.Count)" -ForegroundColor White
    Write-Host ""
    $sqlPorts | ForEach-Object {
        Write-Host "  - Instancia: $($_.Instance) | Puerto: $($_.Port) | Tipo: $($_.Type)" -ForegroundColor Green
        if ($_.Method -and $global:debugEnabled) {
            Write-Host "    Método de detección: $($_.Method)" -ForegroundColor DarkGray
        }
    }
    Write-Host "`n=== FIN DE BÚSQUEDA ===" -ForegroundColor Cyan
}
function Show-ConfirmDialog {
    <#
      .SYNOPSIS
      Confirmación Yes/No con WPF MessageBox
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Message,
        [Parameter(Mandatory)]
        [string]$Title
    )

    Add-Type -AssemblyName PresentationFramework | Out-Null
    $result = [System.Windows.MessageBox]::Show(
        $Message,
        $Title,
        [System.Windows.MessageBoxButton]::YesNo,
        [System.Windows.MessageBoxImage]::Question
    )

    return ($result -eq [System.Windows.MessageBoxResult]::Yes)
}

function Show-InfoDialog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Message,
        [Parameter(Mandatory)]
        [string]$Title
    )
    Add-Type -AssemblyName PresentationFramework | Out-Null
    [System.Windows.MessageBox]::Show(
        $Message,
        $Title,
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Information
    ) | Out-Null
}

function Show-WarnDialog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Message,
        [Parameter(Mandatory)]
        [string]$Title
    )
    Add-Type -AssemblyName PresentationFramework | Out-Null
    [System.Windows.MessageBox]::Show(
        $Message,
        $Title,
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Warning
    ) | Out-Null
}

function Test-7ZipInstalled {
    [CmdletBinding()]
    param()

    $paths = @(
        "C:\Program Files\7-Zip\7z.exe",
        "C:\Program Files (x86)\7-Zip\7z.exe"
    )
    foreach ($p in $paths) {
        if (Test-Path $p) { return $true }
    }

    # Por si existe en PATH
    return [bool](Get-Command 7z -ErrorAction SilentlyContinue)
}

function Get-7ZipPath {
    [CmdletBinding()]
    param()

    $paths = @(
        "C:\Program Files\7-Zip\7z.exe",
        "C:\Program Files (x86)\7-Zip\7z.exe"
    )
    foreach ($p in $paths) {
        if (Test-Path $p) { return $p }
    }

    $cmd = Get-Command 7z -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }

    return $null
}

function Install-7ZipWithChoco {
    [CmdletBinding()]
    param()

    if (-not (Test-ChocolateyInstalled)) {
        Write-DzDebug "[Install-7ZipWithChoco] Chocolatey no está instalado"
        return $false
    }

    try {
        Write-Host "Instalando 7zip con Chocolatey..." -ForegroundColor Yellow
        choco install 7zip -y --no-progress | Out-Null

        # refrescar PATH para el proceso actual (a veces choco no refresca inmediatamente)
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" +
        [System.Environment]::GetEnvironmentVariable("Path", "User")

        Start-Sleep -Seconds 2
        return (Test-7ZipInstalled)
    } catch {
        Write-Host "Error instalando 7zip: $_" -ForegroundColor Red
        return $false
    }
}

function Download-FileWithProgressWpfStream {
    param(
        [Parameter(Mandatory)] [string]$Url,
        [Parameter(Mandatory)] [string]$OutFile,
        [Parameter(Mandatory)] $Window,
        [Parameter()] [ScriptBlock]$OnStatus
    )

    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

    $dir = Split-Path $OutFile -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }

    $total = $null
    try {
        $head = Invoke-WebRequest -Uri $Url -Method Head -UseBasicParsing -ErrorAction Stop
        $cl = $head.Headers["Content-Length"]
        if ($cl) { $total = [int64]$cl }
    } catch {
        $total = $null
    }

    $req = [System.Net.HttpWebRequest]::Create($Url)
    $req.Method = "GET"
    $req.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
    $req.Accept = "*/*"
    $req.AllowAutoRedirect = $true

    $resp = $null
    $inStream = $null
    $outStream = $null

    try {
        $resp = $req.GetResponse()
        if (-not $total) {
            try { $total = [int64]$resp.ContentLength } catch { $total = $null }
        }

        $inStream = $resp.GetResponseStream()
        $outStream = New-Object System.IO.FileStream($OutFile, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)

        $buffer = New-Object byte[] (1024 * 128)
        [int64]$readTotal = 0
        [int64]$lastUi = 0
        $sw = [System.Diagnostics.Stopwatch]::StartNew()

        if ($Window -and $Window.ProgressBar) {
            try {
                $Window.Dispatcher.Invoke([Action] {
                        $Window.ProgressBar.IsIndeterminate = $false
                        $Window.ProgressBar.Value = 0
                    }, [System.Windows.Threading.DispatcherPriority]::Render) | Out-Null
            } catch {}
        }

        while (($read = $inStream.Read($buffer, 0, $buffer.Length)) -gt 0) {
            $outStream.Write($buffer, 0, $read)
            $readTotal += $read

            if (($readTotal - $lastUi) -ge (512KB) -or $sw.ElapsedMilliseconds -ge 200) {
                $lastUi = $readTotal
                $sw.Restart()

                $percent = 0
                if ($total -and $total -gt 0) {
                    $percent = [int][Math]::Min(100, [Math]::Floor(($readTotal * 100.0) / $total))
                }

                $mb = [Math]::Round($readTotal / 1MB, 2)
                $totalMb = if ($total) { [Math]::Round($total / 1MB, 2) } else { $null }
                $msg = if ($totalMb) { "Descargando... $mb / $totalMb MB ($percent%)" } else { "Descargando... $mb MB" }

                if ($Window) {
                    try {
                        Update-WpfProgressBar -Window $Window -Percent $percent -Message $msg
                        $Window.Dispatcher.Invoke([Action] {}, [System.Windows.Threading.DispatcherPriority]::Render) | Out-Null
                    } catch {}
                }

                if ($OnStatus) { try { & $OnStatus $percent $msg } catch {} }
            }
        }

        if ($Window) {
            try {
                Update-WpfProgressBar -Window $Window -Percent 100 -Message "Descarga completada."
                $Window.Dispatcher.Invoke([Action] {}, [System.Windows.Threading.DispatcherPriority]::Render) | Out-Null
            } catch {}
        }

        return $true
    } finally {
        try { if ($outStream) { $outStream.Flush(); $outStream.Close() } } catch {}
        try { if ($inStream) { $inStream.Close() } } catch {}
        try { if ($resp) { $resp.Close() } } catch {}
    }
}

function Show-LZMADialog {
    param(
        [array]$Instaladores
    )
    Write-Host "`n`t- - - Comenzando el proceso - - -" -ForegroundColor Gray
    if (-not $Instaladores -or $Instaladores.Count -eq 0) {
        $LZMAregistryPath = "HKLM:\SOFTWARE\WOW6432Node\Caphyon\Advanced Installer\LZMA"
        if (-not (Test-Path $LZMAregistryPath)) {
            Write-Host "`tNo existe la clave LZMA: $LZMAregistryPath" -ForegroundColor Yellow
            Show-WpfMessageBox -Message "No se encontró Advanced Installer (LZMA) en este equipo.`n`nRuta no existe:`n$LZMAregistryPath" `
                -Title "Sin instaladores" -Buttons OK -Icon Information | Out-Null
            return
        }
        try {
            $carpetasPrincipales = Get-ChildItem -Path $LZMAregistryPath -ErrorAction Stop | Where-Object { $_.PSIsContainer }
            if (-not $carpetasPrincipales -or $carpetasPrincipales.Count -lt 1) {
                Write-Host "`tNo se encontraron carpetas principales." -ForegroundColor Yellow
                Show-WpfMessageBox -Message "No se encontraron carpetas principales en la ruta del registro." `
                    -Title "Sin resultados" -Buttons OK -Icon Information | Out-Null
                return
            }
            $tmp = @()
            foreach ($carpeta in $carpetasPrincipales) {
                $subdirs = Get-ChildItem -Path $carpeta.PSPath -ErrorAction SilentlyContinue | Where-Object { $_.PSIsContainer }
                foreach ($sd in $subdirs) {
                    $tmp += [PSCustomObject]@{
                        Name = $sd.PSChildName
                        Path = $sd.PSPath
                    }
                }
            }
            if (-not $tmp -or $tmp.Count -lt 1) {
                Write-Host "`tNo se encontraron subcarpetas." -ForegroundColor Yellow
                Show-WpfMessageBox -Message "No se encontraron instaladores (subcarpetas) en la ruta del registro." `
                    -Title "Sin resultados" -Buttons OK -Icon Information | Out-Null
                return
            }
            $Instaladores = $tmp | Sort-Object Name -Descending
        } catch {
            Write-Host "`tError accediendo al registro: $($_.Exception.Message)" -ForegroundColor Red
            Show-WpfMessageBox -Message "Error accediendo al registro:`n$($_.Exception.Message)" `
                -Title "Error" -Buttons OK -Icon Error | Out-Null
            return
        }
    }
    [xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        Title="Carpetas LZMA"
        Height="240" Width="520"
        WindowStartupLocation="CenterOwner"
        ResizeMode="NoResize"
        ShowInTaskbar="False">
    <Grid Margin="12">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ComboBox Name="cmbInstallers" Grid.Row="0" Height="28" FontSize="12" Margin="0,0,0,10"/>
        <TextBlock Name="lblExePath" Grid.Row="1" Text="AI_ExePath: -" FontSize="12" Foreground="Red" TextWrapping="Wrap" Margin="0,0,0,12" MinHeight="40"/>
        <StackPanel Grid.Row="3" Orientation="Horizontal" HorizontalAlignment="Right">
            <Button Name="btnRename" Content="Renombrar" Width="110" Height="30" Margin="0,0,10,0" IsEnabled="False"/>
            <Button Name="btnExit" Content="Salir" Width="110" Height="30" IsCancel="True"/>
        </StackPanel>
    </Grid>
</Window>
"@

    $ui = New-WpfWindow -Xaml $xaml -PassThru
    $window = $ui.Window
    $c = $ui.Controls
    try {
        if ($Global:window -is [System.Windows.Window]) {
            $window.Owner = $Global:window
            $window.WindowStartupLocation = "CenterOwner"
        } else {
            $window.WindowStartupLocation = "CenterScreen"
        }
    } catch {
        $window.WindowStartupLocation = "CenterScreen"
    }
    $c['cmbInstallers'].Items.Clear()
    $c['cmbInstallers'].Items.Add("Selecciona instalador a renombrar") | Out-Null
    foreach ($i in $Instaladores) {
        $c['cmbInstallers'].Items.Add($i.Name) | Out-Null
    }
    $c['cmbInstallers'].SelectedIndex = 0
    $updateUi = {
        $idx = $c['cmbInstallers'].SelectedIndex
        $c['btnRename'].IsEnabled = ($idx -gt 0)
        if ($idx -gt 0) {
            $selectedName = $c['cmbInstallers'].SelectedItem
            $item = $Instaladores | Where-Object Name -eq $selectedName | Select-Object -First 1
            if ($item -and $item.Path) {
                $prop = Get-ItemProperty -Path $item.Path -Name "AI_ExePath" -ErrorAction SilentlyContinue
                if ($prop -and $prop.AI_ExePath) {
                    $c['lblExePath'].Text = "AI_ExePath: $($prop.AI_ExePath)"
                } else {
                    $c['lblExePath'].Text = "AI_ExePath: No encontrado"
                }
            } else {
                $c['lblExePath'].Text = "AI_ExePath: No encontrado"
            }
        } else {
            $c['lblExePath'].Text = "AI_ExePath: -"
        }
    }
    $c['cmbInstallers'].Add_SelectionChanged({ & $updateUi })
    & $updateUi
    $c['btnRename'].Add_Click({
            $idx = $c['cmbInstallers'].SelectedIndex
            if ($idx -le 0) { return }
            $nombre = [string]$c['cmbInstallers'].SelectedItem
            $item = $Instaladores | Where-Object Name -eq $nombre | Select-Object -First 1
            if (-not $item) { return }
            $rutaVieja = $item.Path
            $nuevoNombre = "$nombre.backup"
            $msg = "¿Está seguro de renombrar:`n$rutaVieja`n`na:`n$nuevoNombre ?"
            $conf = Show-WpfMessageBox -Message $msg -Title "Confirmar renombrado" -Buttons YesNo -Icon Warning
            if ($conf -eq [System.Windows.MessageBoxResult]::Yes) {
                try {
                    Rename-Item -Path $rutaVieja -NewName $nuevoNombre -ErrorAction Stop
                    Show-WpfMessageBox -Message "Registro renombrado correctamente." -Title "Éxito" -Buttons OK -Icon Information | Out-Null
                    $window.Close()
                } catch {
                    Show-WpfMessageBox -Message "Error al renombrar:`n$($_.Exception.Message)" -Title "Error" -Buttons OK -Icon Error | Out-Null
                }
            }
        })
    $c['btnExit'].Add_Click({
            Write-Host "`tCancelado por el usuario." -ForegroundColor Yellow
            $window.Close()
        })
    $window.ShowDialog() | Out-Null
}

function Show-SQLselector {
    param(
        [array]$Managers,
        [array]$SSMSVersions
    )

    # Helper: intenta asignar owner ($window) para modal real
    function Set-DialogOwner {
        param([System.Windows.Window]$Dialog)

        try {
            if (Get-Variable -Name window -Scope Global -ErrorAction SilentlyContinue) {
                $Dialog.Owner = $Global:window
                return
            }
            if (Get-Variable -Name window -Scope Script -ErrorAction SilentlyContinue) {
                $Dialog.Owner = $script:window
                return
            }
        } catch { }
    }

    # Helper: bits para managers
    function Get-ManagerBits {
        param([string]$Path)

        # System32 = 64-bit, SysWOW64 = 32-bit
        if ($Path -match "\\SysWOW64\\") { return "32 bits" }
        return "64 bits"
    }

    # Helper: versión del manager (SQLServerManager15.msc => 15)
    function Get-ManagerVersion {
        param([string]$Path)
        if ($Path -match "SQLServerManager(\d+)\.msc") { return $matches[1] }
        return "?"
    }

    # Helper: crea items para listbox (Display + Path)
    function New-SelectorItem {
        param(
            [string]$Path,
            [string]$Display
        )
        [PSCustomObject]@{
            Path    = $Path
            Display = $Display
        }
    }

    # Helper: construye un diálogo genérico de selección
    function Show-PathSelectionDialog {
        param(
            [string]$Title,
            [string]$Prompt,
            [array]$Items,               # array de PSCustomObject {Path, Display}
            [scriptblock]$OnExecute,     # recibe $SelectedPath
            [string]$ExecuteButtonText = "Ejecutar"
        )

        $dialog = New-Object System.Windows.Window
        $dialog.Title = $Title
        $dialog.Width = 780
        $dialog.Height = 420
        $dialog.WindowStartupLocation = "CenterOwner"
        $dialog.ResizeMode = "NoResize"
        if ($Global:window -is [System.Windows.Window]) {
            $dialog.Owner = $Global:window
        }

        # 2) Centrar respecto al owner
        $dialog.WindowStartupLocation = "CenterOwner"

        # 3) Fallback: si no hay Owner, centrar en pantalla
        if (-not $dialog.Owner) {
            $dialog.WindowStartupLocation = "CenterScreen"
        }
        Set-DialogOwner -Dialog $dialog

        $root = New-Object System.Windows.Controls.StackPanel
        $root.Margin = New-Object System.Windows.Thickness(10)

        $label = New-Object System.Windows.Controls.TextBlock
        $label.Text = $Prompt
        $label.Margin = New-Object System.Windows.Thickness(0, 0, 0, 10)
        $label.FontSize = 13
        $root.Children.Add($label) | Out-Null

        # ListBox: aquí va lo "legible": version/bits + RUTA COMPLETA
        $listBox = New-Object System.Windows.Controls.ListBox
        $listBox.Height = 250
        $listBox.FontSize = 12
        $listBox.DisplayMemberPath = "Display"
        $listBox.SelectedValuePath = "Path"
        foreach ($it in $Items) { $null = $listBox.Items.Add($it) }
        $listBox.SelectedIndex = 0
        $root.Children.Add($listBox) | Out-Null

        # Ruta seleccionada (para copiar fácil)
        $pathLabelTitle = New-Object System.Windows.Controls.TextBlock
        $pathLabelTitle.Text = "Ruta seleccionada:"
        $pathLabelTitle.Margin = New-Object System.Windows.Thickness(0, 10, 0, 2)
        $pathLabelTitle.FontSize = 11
        $root.Children.Add($pathLabelTitle) | Out-Null

        $pathLabel = New-Object System.Windows.Controls.TextBlock
        $pathLabel.Text = ""
        $pathLabel.FontSize = 11
        $pathLabel.FontFamily = "Consolas"
        $pathLabel.TextWrapping = "Wrap"
        $pathLabel.Margin = New-Object System.Windows.Thickness(0, 0, 0, 10)
        $root.Children.Add($pathLabel) | Out-Null

        $updatePath = {
            if ($listBox.SelectedValue) { $pathLabel.Text = $listBox.SelectedValue }
            else { $pathLabel.Text = "" }
        }
        & $updatePath
        $listBox.Add_SelectionChanged({ & $updatePath })

        $btnPanel = New-Object System.Windows.Controls.StackPanel
        $btnPanel.Orientation = "Horizontal"
        $btnPanel.HorizontalAlignment = "Right"

        $cancelButton = New-Object System.Windows.Controls.Button
        $cancelButton.Content = "Cancelar"
        $cancelButton.Width = 95
        $cancelButton.Margin = New-Object System.Windows.Thickness(0, 0, 10, 0)
        $cancelButton.Add_Click({
                $dialog.DialogResult = $false
                $dialog.Close()
            })

        $okButton = New-Object System.Windows.Controls.Button
        $okButton.Content = $ExecuteButtonText
        $okButton.Width = 95
        $okButton.IsDefault = $true
        $okButton.Add_Click({
                if ($listBox.SelectedValue) {
                    try {
                        & $OnExecute $listBox.SelectedValue
                        $dialog.DialogResult = $true
                        $dialog.Close()
                    } catch {
                        [System.Windows.MessageBox]::Show(
                            "Error al ejecutar:`n$($_.Exception.Message)",
                            "Error",
                            [System.Windows.MessageBoxButton]::OK,
                            [System.Windows.MessageBoxImage]::Error
                        ) | Out-Null
                    }
                }
            })

        $btnPanel.Children.Add($cancelButton) | Out-Null
        $btnPanel.Children.Add($okButton) | Out-Null
        $root.Children.Add($btnPanel) | Out-Null

        $dialog.Content = $root
        $null = $dialog.ShowDialog()
    }

    # =========================
    # 1) MANAGERS (SQLServerManager*.msc)
    # =========================
    if ($Managers -and $Managers.Count -gt 0) {

        $items = @()

        $unique = $Managers | Where-Object { $_ } | Select-Object -Unique
        foreach ($m in $unique) {
            $ver = Get-ManagerVersion -Path $m
            $bits = Get-ManagerBits    -Path $m

            # Display legible (incluye RUTA COMPLETA)
            $display = "SQLServerManager$ver  |  $bits  |  $m"
            $items += (New-SelectorItem -Path $m -Display $display)
        }

        Show-PathSelectionDialog `
            -Title  "Seleccionar Configuration Manager" `
            -Prompt "Seleccione la versión de SQL Server Configuration Manager a ejecutar:" `
            -Items  $items `
            -OnExecute {
            param($selectedPath)
            Write-Host "`tEjecutando SQL Server Configuration Manager desde: $selectedPath" -ForegroundColor Green
            Start-Process -FilePath $selectedPath
        } `
            -ExecuteButtonText "Abrir"

        return
    }

    # =========================
    # 2) SSMS (Ssms.exe)
    # =========================
    if ($SSMSVersions -and $SSMSVersions.Count -gt 0) {

        $items = @()
        $unique = $SSMSVersions | Where-Object { $_ } | Select-Object -Unique

        foreach ($p in $unique) {
            # Display legible: producto + versión + ruta completa
            try {
                $vi = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($p)
                $prod = if ($vi.ProductName) { $vi.ProductName } else { "SSMS" }
                $ver = if ($vi.FileVersion) { $vi.FileVersion }  else { "" }

                $display = "$prod  |  $ver  |  $p"
                $items += (New-SelectorItem -Path $p -Display $display)
            } catch {
                $items += (New-SelectorItem -Path $p -Display "SSMS  |  $p")
            }
        }

        Show-PathSelectionDialog `
            -Title  "Seleccionar SSMS" `
            -Prompt "Seleccione la versión de SQL Server Management Studio a ejecutar:" `
            -Items  $items `
            -OnExecute {
            param($selectedPath)
            Write-Host "`tEjecutando: $selectedPath" -ForegroundColor Green
            Start-Process -FilePath $selectedPath
        } `
            -ExecuteButtonText "Ejecutar"

        return
    }

    Write-Host "Show-SQLselector: No se recibieron rutas para Managers ni para SSMS." -ForegroundColor Yellow
}
function Show-IPConfigDialog {

    Write-Host "`n`t- - - Comenzando el proceso - - -" -ForegroundColor Gray

    # Helper: validar IPv4
    function Test-IPv4 {
        param([string]$Ip)
        if ([string]::IsNullOrWhiteSpace($Ip)) { return $false }
        $Ip = $Ip.Trim()
        return [System.Net.IPAddress]::TryParse($Ip, [ref]([System.Net.IPAddress]$null)) -and ($Ip -match '^\d{1,3}(\.\d{1,3}){3}$')
    }

    # Helper: refrescar texto de IPs
    function Get-AdapterIpsText {
        param([string]$Alias)
        try {
            $ips = Get-NetIPAddress -InterfaceAlias $Alias -AddressFamily IPv4 -ErrorAction SilentlyContinue |
            Select-Object -ExpandProperty IPAddress
            if ($ips) { return "IPs asignadas: " + ($ips -join ", ") }
        } catch { }
        return "IPs asignadas: -"
    }

    # XAML
    [xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        Title="Asignación de IPs"
        Height="250" Width="560"
        WindowStartupLocation="CenterOwner"
        ResizeMode="NoResize"
        ShowInTaskbar="False">
    <Grid Margin="12">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
        </Grid.RowDefinitions>

        <TextBlock Grid.Row="0"
                   Text="Seleccione el adaptador de red:"
                   FontSize="13"
                   Margin="0,0,0,8"/>

        <ComboBox Name="cmbAdapters"
                  Grid.Row="1"
                  Height="28"
                  FontSize="12"
                  Margin="0,0,0,10"/>

        <TextBlock Name="lblIps"
                   Grid.Row="2"
                   Text="IPs asignadas: -"
                   FontSize="12"
                   TextWrapping="Wrap"
                   Margin="0,0,0,12"
                   MinHeight="36"/>

        <StackPanel Grid.Row="3" Orientation="Horizontal" HorizontalAlignment="Right">
            <Button Name="btnAssignIp" Content="Asignar Nueva IP" Width="140" Height="32" Margin="0,0,10,0" IsEnabled="False"/>
            <Button Name="btnDhcp"     Content="Cambiar a DHCP"  Width="140" Height="32" Margin="0,0,10,0" IsEnabled="False"/>
            <Button Name="btnClose"    Content="Cerrar"         Width="110" Height="32" IsCancel="True"/>
        </StackPanel>
    </Grid>
</Window>
"@

    $ui = New-WpfWindow -Xaml $xaml -PassThru
    $window = $ui.Window
    $c = $ui.Controls

    # CenterOwner real
    try {
        if ($Global:window -is [System.Windows.Window]) {
            $window.Owner = $Global:window
            $window.WindowStartupLocation = "CenterOwner"
        } else {
            $window.WindowStartupLocation = "CenterScreen"
        }
    } catch {
        $window.WindowStartupLocation = "CenterScreen"
    }

    # Cargar adaptadores Up
    $adapters = @(Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq "Up" })
    $c['cmbAdapters'].Items.Clear()
    $c['cmbAdapters'].Items.Add("Selecciona 1 adaptador de red") | Out-Null
    foreach ($a in $adapters) { $c['cmbAdapters'].Items.Add($a.Name) | Out-Null }
    $c['cmbAdapters'].SelectedIndex = 0

    # Actualizar UI según selección
    $updateUi = {
        $sel = [string]$c['cmbAdapters'].SelectedItem
        $valid = ($sel -and $sel -ne "Selecciona 1 adaptador de red")

        $c['btnAssignIp'].IsEnabled = $valid
        $c['btnDhcp'].IsEnabled = $valid

        if ($valid) {
            $c['lblIps'].Text = (Get-AdapterIpsText -Alias $sel)
        } else {
            $c['lblIps'].Text = "IPs asignadas: -"
        }
    }

    $c['cmbAdapters'].Add_SelectionChanged({ & $updateUi })
    & $updateUi

    # Botón: Asignar nueva IP
    $c['btnAssignIp'].Add_Click({
            $alias = [string]$c['cmbAdapters'].SelectedItem
            if (-not $alias -or $alias -eq "Selecciona 1 adaptador de red") {
                Show-WpfMessageBox -Message "Por favor, selecciona un adaptador de red." -Title "Error" -Buttons OK -Icon Error | Out-Null
                return
            }

            # Config actual
            $current = Get-NetIPAddress -InterfaceAlias $alias -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -First 1
            if (-not $current) {
                Show-WpfMessageBox -Message "No se pudo obtener la configuración IPv4 del adaptador." -Title "Error" -Buttons OK -Icon Error | Out-Null
                return
            }

            $prefixLen = $current.PrefixLength

            # Pedir IP
            $newIp = New-WpfInputDialog -Title "Nueva IP" -Prompt "Ingrese la nueva dirección IP IPv4:" -DefaultValue ""
            if ([string]::IsNullOrWhiteSpace($newIp)) { return }

            if (-not (Test-IPv4 -Ip $newIp)) {
                Show-WpfMessageBox -Message "La IP '$newIp' no es válida." -Title "Error" -Buttons OK -Icon Error | Out-Null
                return
            }

            # Evitar duplicado
            $exists = Get-NetIPAddress -InterfaceAlias $alias -AddressFamily IPv4 -ErrorAction SilentlyContinue |
            Where-Object { $_.IPAddress -eq $newIp.Trim() }
            if ($exists) {
                Show-WpfMessageBox -Message "La IP $newIp ya está asignada a $alias." -Title "Error" -Buttons OK -Icon Error | Out-Null
                return
            }

            try {
                New-NetIPAddress -IPAddress $newIp.Trim() -PrefixLength $prefixLen -InterfaceAlias $alias -ErrorAction Stop | Out-Null
                Show-WpfMessageBox -Message "Se agregó la IP $newIp al adaptador $alias." -Title "Éxito" -Buttons OK -Icon Information | Out-Null
                $c['lblIps'].Text = (Get-AdapterIpsText -Alias $alias)
            } catch {
                Show-WpfMessageBox -Message "Error al agregar IP:`n$($_.Exception.Message)" -Title "Error" -Buttons OK -Icon Error | Out-Null
            }
        })

    # Botón: Cambiar a DHCP
    $c['btnDhcp'].Add_Click({
            $alias = [string]$c['cmbAdapters'].SelectedItem
            if (-not $alias -or $alias -eq "Selecciona 1 adaptador de red") {
                Show-WpfMessageBox -Message "Por favor, selecciona un adaptador de red." -Title "Error" -Buttons OK -Icon Error | Out-Null
                return
            }

            # Ver si ya es DHCP
            $any = Get-NetIPAddress -InterfaceAlias $alias -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($any -and $any.PrefixOrigin -eq "Dhcp") {
                Show-WpfMessageBox -Message "El adaptador ya está en DHCP." -Title "Información" -Buttons OK -Icon Information | Out-Null
                return
            }

            $conf = Show-WpfMessageBox -Message "¿Está seguro de que desea cambiar a DHCP?" -Title "Confirmación" -Buttons YesNo -Icon Question
            if ($conf -ne [System.Windows.MessageBoxResult]::Yes) { return }

            try {
                # Quitar IPs manuales
                $manualIps = Get-NetIPAddress -InterfaceAlias $alias -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                Where-Object { $_.PrefixOrigin -eq "Manual" }
                foreach ($ip in $manualIps) {
                    Remove-NetIPAddress -IPAddress $ip.IPAddress -PrefixLength $ip.PrefixLength -InterfaceAlias $alias -Confirm:$false -ErrorAction SilentlyContinue
                }

                # Habilitar DHCP y reset DNS
                Set-NetIPInterface -InterfaceAlias $alias -Dhcp Enabled -ErrorAction Stop | Out-Null
                Set-DnsClientServerAddress -InterfaceAlias $alias -ResetServerAddresses -ErrorAction SilentlyContinue | Out-Null

                Show-WpfMessageBox -Message "Se cambió a DHCP en el adaptador $alias." -Title "Éxito" -Buttons OK -Icon Information | Out-Null
                $c['lblIps'].Text = "Generando IP por DHCP. Seleccione de nuevo."
            } catch {
                Show-WpfMessageBox -Message "Error al cambiar a DHCP:`n$($_.Exception.Message)" -Title "Error" -Buttons OK -Icon Error | Out-Null
            }
        })

    $c['btnClose'].Add_Click({ $window.Close() })

    $window.ShowDialog() | Out-Null
}

Export-ModuleMember -Function @(
    'Get-DzToolsConfigPath',
    'Get-DzDebugPreference',
    'Initialize-DzToolsConfig',
    'Write-DzDebug',
    'Test-Administrator',
    'Get-SystemInfo',
    'Clear-TemporaryFiles',
    'Test-ChocolateyInstalled',
    'Install-Chocolatey',
    'Get-AdminGroupName',
    'Invoke-DiskCleanup',
    'Stop-CleanmgrProcesses',
    'Show-SystemComponents',
    'Test-SameHost',
    'Test-7ZipInstalled',
    'Test-MegaToolsInstalled',
    'Check-Permissions',
    'Download-FileWithProgressWpfStream',
    'Refresh-AdapterStatus',
    'Get-NetworkAdapterStatus',
    'Start-SystemUpdate',
    'Get-SqlPortWithDebug',
    'Show-SqlPortsInfo',
    'Show-ConfirmDialog',
    'Show-InfoDialog',
    'Show-WarnDialog',
    'Get-7ZipPath',
    'Install-7ZipWithChoco',
    'Show-LZMADialog',
    'Show-SQLselector',
    'Show-IPConfigDialog'
)